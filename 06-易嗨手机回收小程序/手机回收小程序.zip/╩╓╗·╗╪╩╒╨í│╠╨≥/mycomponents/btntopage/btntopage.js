Component({
  methods: {
    pageto(){
      wx.navigateTo({
        url: '/pages/evaluation/othercalcprice',
      });
    }
  }
});