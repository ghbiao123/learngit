module.exports = {
  siteroot: "https://sjhs.zlogic.cn"
  // siteroot: "http://hs.com"
}