Component({
  properties: {
    icon: {
      type: String,
      value: ""
    },
    text: {
      type: String,
      value: ""
    },
    selected: {
      type: Boolean,
      value: false
    }
  }
});