Component({
  options: {
    addGlobalClass: true
  },
  properties: {
    status: {
      type: Number,
      value: 15
    }
  }
});