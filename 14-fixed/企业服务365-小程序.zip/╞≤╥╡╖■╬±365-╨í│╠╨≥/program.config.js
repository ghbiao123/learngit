module.exports = {
  // siteroot: "http://equipment.do"
  // siteroot: "https://weixiu-demo.zlogic.cn"
  siteroot: "https://weixiu.nhwy365.com"
}
// https://weixiu.nhwy365.com/NwzrIKgHfA.php/index/login