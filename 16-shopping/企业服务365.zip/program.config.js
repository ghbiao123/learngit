module.exports = {
  siteroot: "https://bwc.osxiaochengxu.cn"
}